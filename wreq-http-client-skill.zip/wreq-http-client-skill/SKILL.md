---
name: Wreq Http Client Skill
description: Use wreq http client in Python when is needed, for example, transform a CURL or any http requests from other clients in Python to wreq implementation
---

## Overview 

Wreq An ergonomic and modular Python HTTP Client for high-fidelity protocol matching, featuring customizable TLS, JA3/JA4, and HTTP/2 signature capabilities. Here we are gonna describe how it works and how you must to configure and write the wreq http client implementation. \

## Features

- Async and Blocking Clients
- Plain bodies, JSON, urlencoded, multipart
- HTTP Trailer
- Cookie Store
- Redirect Policy
- Original Header
- Rotating Proxies
- Connection Pooling
- Streaming Transfers
- Zero-Copy Transfers
- WebSocket Upgrade
- HTTPS via BoringSSL
- Free-Threaded Safety
- Automatic Decompression
- Certificate Store (CAs & mTLS)


## Example 

### Installation

- pip install wreq

### Code 


```
import asyncio
from wreq import Client, Emulation


async def main():
    # Build a client
    client = Client(emulation=Emulation.Firefox149)

    # Use the API you're already familiar with
    resp = await client.get("https://tls.peet.ws/api/all")
    print(await resp.text())


if __name__ == "__main__":
    asyncio.run(main())
```

## Documentation

### Code Examples
 
You can check https://github.com/0x676e67/wreq-python/tree/main/examples to get examples of: 

- blocking/*.py
- auth.py
- basic_auth.py
- bearer_auth.py
- body.py
- emulation.py
- exceptions.py
- form.py
- header_map.py
- http1_websocket.py
- http2_websocket.py
- json.py
- keylog.py
- multipart.py
- orig_headers.py
- proxy.py
- query.py
- redirect.py
- request.py
- stream.py


### Deep Wiki

You can check this Deep Wiki link https://deepwiki.com/0x676e67/wreq-python for getting more technical information about the client


### Official Documentation

Also, you can check the official documentation site https://python.wreq.org/en/latest/ or the README.md from the repository https://github.com/0x676e67/wreq-python


## When to use this Wreq client

You should use this guidelines whenever the user is asking for: 

- Convert CURL to wreq implementation
- Convert any other HTTP client code (in python) to wreq equivalent
- Any user instructions that is intended to use the wreq for some technical requirement
